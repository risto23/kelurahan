<footer id="footer" class="footer bg-dark">
        <div class="foot-credit">
            <div class="container">
                <p>Kecamatan Panggarangan &copy; 2017</p>
            </div><!-- /container -->
        </div><!-- /foot-credit -->
    </footer>