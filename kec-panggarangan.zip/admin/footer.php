<footer class="main-footer">
    <div class="pull-right hidden-xs">
    	<b>Copyright © 2017</b>
    </div>
    <strong>Kecamatan Panggarangan</strong>
</footer>